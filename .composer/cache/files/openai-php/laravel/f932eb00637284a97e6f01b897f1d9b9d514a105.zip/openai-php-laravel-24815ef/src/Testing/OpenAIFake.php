<?php

namespace OpenAI\Laravel\Testing;

use OpenAI\Testing\ClientFake;

class OpenAIFake extends ClientFake {}
